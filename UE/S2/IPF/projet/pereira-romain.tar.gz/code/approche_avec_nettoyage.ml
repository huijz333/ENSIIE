(**
 *	5. Approche avec nettoyage:
 *
 *	R�ponses aux questions 6, 7
 *)

(**
 *	Fonction 'sum'
 *
 *	@param  : int list -> int
 *	@return : la somme des �l�ments de la liste d'entier
 *)