(**
 *	Module de fonction internes, facilitant le reste du programme.@author 
 *		1 - Fonctions permettant de travailler avec des ensembles math�matiques
 *			(sous forme de liste OCaml sans doublons)
 *
 *		2 - Fonction pratiques sur les listes	
 *)

(**
 *	@param  : 'a list -> 'a -> bool
 *	@return : renvoie vrai si la liste contient l'�l�ment, faux sinon
 *)
let rec list_contains =	function l -> function e ->
													match l with
                					| []	-> false
                					| h::t	-> 	if h = e then
                								true
                							else
                								list_contains t e
                			;;

(**
 *	@param  : 'a list -> 'a -> 'a list
 *	@return : s u {x} ('s union {x}')
 *)
let set_add = function s -> function x -> if list_contains s x then s else x::s ;;

(**
 *	@type   : 'a list -> 'a list
 *	@return : converti la liste en ensemble contenant tous ces �l�ments
 *)
let rec list_to_set =	function l ->
												match l with
                    		| []	-> []
                    		| h::t	-> set_add (list_to_set t) h
                    ;;

(**
 *	@type   : 'a list -> 'a list -> 'a list
 *	@return : s1 n s2 ('s1 inter s2')
 *)
let rec set_intersect =	function s1 -> function s2 ->
                        	match s1 with
                        	| []	->	[]
                        	| h::t	->	if list_contains s2 h then
                        								h::(set_intersect t s2)
                        							else
                        								set_intersect t s2
                        ;;

(**
 *	@type   : 'a list -> 'a list -> 'a list
 *	@return : s1 u s2 ('s1 union s2')
 *)
let set_union = function s1 -> function s2 -> list_to_set (s1 @ s2) ;;

(**
 *	@param  : 'a list -> ('a -> unit) -> unit
 *	@ensure : affiche la liste donn� en param�tre, en appliquant
 *						la fonction 'print_elem' a chacun de ces �l�ments
 *)
let rec lprint =	function l -> function print_elem ->
												Printf.printf "[" ;
												match l with
												| []		->	Printf.printf "]"
												| [x]		->	print_elem x ; Printf.printf "]\n"
												| h::t	->	print_elem h ; lprint t print_elem
											;;
(**
 *	@param  : int list -> unit
 *	@ensure : affiche la liste de liste d'entier donn� en param�tre
 *)
let lliprint =	function ll ->
									lprint ll (function l -> lprint l (function x -> Printf.printf "%d" x))
								;;
