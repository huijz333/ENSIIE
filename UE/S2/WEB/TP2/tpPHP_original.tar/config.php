<?php
/* Le fichier config.php doit contenir l\'initialisation des variables php $nomBase avec le nom de la base de données dans laquelle vous avez créé la relation tp_client et $nomuser avec votre login */

$nom_hote= "pgsql2";
$nom_base = "tpphp";
$nom_user = "tpphp";
$mdp="tpphp";

$AUTHENT=0;

?>
