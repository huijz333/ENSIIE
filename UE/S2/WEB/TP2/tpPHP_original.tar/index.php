<?php
include("tpModele.php");
include("tpVue.php");

verif_authent();

enTete("Menu"); 

affiche_menu();

retour_menu();

pied();
?>

