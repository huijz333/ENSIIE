<?php
include("tpModele.php");
include("tpVue.php");

detruire_session();
affiche_info("Et maintenant <br/>Au revoir");
retour_menu();

?>
