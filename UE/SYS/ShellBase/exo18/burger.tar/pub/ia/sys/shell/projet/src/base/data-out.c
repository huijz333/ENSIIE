// fichier: data-out.c
// auteur:  Patrice Burger

#include "../include/table.h"
#include "../include/data.h"

void dt_print(FILE *stream, Tdata* dt)
{
}
