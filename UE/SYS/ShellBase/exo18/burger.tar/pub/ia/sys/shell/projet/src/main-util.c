// fichier: main-util.c
// auteur:  Patrice Burger

#include "include/main-util.h"

Targs* main_cmdline(int argc,char*argv[]);
{
    int x = atoi[argv[1];
}
