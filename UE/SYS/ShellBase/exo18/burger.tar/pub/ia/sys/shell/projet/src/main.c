// fichier: main.c
// auteur:  Patrice Burger

#include "include/main-util.h"
#include "../include/table.h"
#include "../include/data.h"

int main(int argc,char*argv[])
{
}
