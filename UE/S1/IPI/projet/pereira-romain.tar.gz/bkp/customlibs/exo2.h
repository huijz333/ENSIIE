#ifndef EXO2_H
# define EXO2_H

# include "ipi.h"	/* constantes */
# include "dijkstra.h"
# include "astar.h"

#endif
