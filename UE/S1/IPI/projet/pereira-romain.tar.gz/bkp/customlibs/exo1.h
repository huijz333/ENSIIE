#ifndef EXO1_H
# define EXO1_H

# include "ipi.h"	/* constantes */
# include "array.h"	/* file pour générer le chemin */
# include "breadth_search.h" /* parcours en largeur */
# include "node.h"

#endif
