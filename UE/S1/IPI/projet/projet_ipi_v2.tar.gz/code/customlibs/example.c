#include <stdio.h>

#include "example.h"

void example_print(){
  printf("Ceci a été appelé depuis une bibliothèque personnelle \n");
}
