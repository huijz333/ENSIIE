
#ifndef IPI_EXAMPLE_H
#define IPI_EXAMPLE_H

void example_print();

#endif
