void main() {
	char pif[8192 * 1024];
}

