#! /bin/bash

ls /tmp
